package com.onlineshoemart.service;

import java.util.List;
import java.util.Optional;

import com.onlineshoemart.model.Products;

public interface ProductsService 
	{
		 Products createProducts(Products products);
		     List<Products>  getAllProducts();
		     Optional<Products> getProducts(int id);
		    Products updateProducts(int id,Products products);
		    void deleteProducts(int id);

		}


