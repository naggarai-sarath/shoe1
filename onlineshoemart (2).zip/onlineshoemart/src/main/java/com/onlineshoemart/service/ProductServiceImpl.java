package com.onlineshoemart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineshoemart.model.Products;
import com.onlineshoemart.repository.ProductsRepository;

@Service
public class ProductServiceImpl implements ProductsService {

    @Autowired
    private ProductsRepository productsRepository;

    @Override
    public Products createProducts(Products products) {
        System.out.println("two-c");
        return productsRepository.save(products);
    }

    @Override
    public List<Products> getAllProducts() {
        return productsRepository.findAll();
    }

    @Override
    public Optional<Products> getProducts(int product_id) {
    	System.out.println("getProducts");
        return productsRepository.findById(product_id);
    }

    @Override
    public Products updateProducts(int product_id, Products products) {
        Optional<Products> existingProductsOptional = productsRepository.findById(product_id);

        if (existingProductsOptional.isPresent()) {
            Products existingProducts = existingProductsOptional.get();
            existingProducts.setProduct_id(products.getProduct_id());
            // Update other fields as needed

            return productsRepository.save(existingProducts);
        } else {
            // Handle the case where the employee with the given id is not found
            return null; // You can throw an exception or return a meaningful response
        }
    }

    @Override
    public void deleteProducts(int product_id) {
        productsRepository.deleteById(product_id);
    }
}