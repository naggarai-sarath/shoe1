package com.onlineshoemart.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="products")
public class Products 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int product_id;
	private String product_name;
	private String descriptionText;
	private double price;
	private int stock_quantity;
	private String category;
	
	public Products() {
		
	}
	
	public Products(int product_id, String product_name, String descriptionText, double price, int stock_quantity,
			String category) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.descriptionText = descriptionText;
		this.price = price;
		this.stock_quantity = stock_quantity;
		this.category = category;
	}
	
	
	@Override
	public String toString() {
		return "Products [product_id=" + product_id + ", product_name=" + product_name + ", descriptionText="
				+ descriptionText + ", price=" + price + ", stock_quantity=" + stock_quantity + ", category=" + category
				+ ", getProduct_id()=" + getProduct_id() + ", getProduct_name()=" + getProduct_name()
				+ ", getDescriptionText()=" + getDescriptionText() + ", getPrice()=" + getPrice()
				+ ", getStock_quantity()=" + getStock_quantity() + ", getCategory()=" + getCategory() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getDescriptionText() {
		return descriptionText;
	}
	public void setDescriptionText(String descriptionText) {
		this.descriptionText = descriptionText;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStock_quantity() {
		return stock_quantity;
	}
	public void setStock_quantity(int stock_quantity) {
		this.stock_quantity = stock_quantity;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
}
