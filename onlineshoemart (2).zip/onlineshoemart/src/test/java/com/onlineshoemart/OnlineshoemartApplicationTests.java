package com.onlineshoemart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineshoemartApplicationTests {

	@Test
	void contextLoads() {
	}

}
